package com.example.dato_kuknishvili_final;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException, SQLException {

        DBUtils.getInstance().openConnection();
        PieChart pieChart = new PieChart();

        pieChart.setData(DBUtils.getInstance().getGroupedProducts());


        GridPane root = new GridPane();
        root.setStyle("-fx-padding: 50; -fx-hgap: 50");


        GridPane formRoot = new GridPane();

        Label headerLabel = new Label("Add Product");
        headerLabel.setStyle("-fx-font-size: 20; -fx-font-weight: bold");

        Label nameLabel = new Label("Product Name");
        Label priceLabel = new Label("Price");
        Label quantityLabel = new Label("Quantity");


        TextField nameField = new TextField();
        nameField.setStyle("-fx-min-height: 30; -fx-min-width: ${Double.MAX_VALUE)}");

        TextField priceField = new TextField();
        priceField.setStyle("-fx-min-height: 30; -fx-min-width: ${Double.MAX_VALUE)}");

        TextField quantityField = new TextField();
        quantityField.setStyle("-fx-min-height: 30; -fx-min-width: ${Double.MAX_VALUE)}");


        VBox nameContainer = new VBox(5, nameLabel, nameField);
        VBox priceContainer = new VBox(5, priceLabel, priceField);
        VBox quantityContainer = new VBox(5, quantityLabel, quantityField);

        Button addButton = new Button("Add Product");
        addButton.setStyle("-fx-background-color: #1ab75b; -fx-min-height: 40; -fx-cursor: hand; -fx-text-fill: #fff; -fx-min-width: 300");

        addButton.setOnAction(e -> {
            try {
                DBUtils.getInstance().insertProduct(nameField.getText(), Float.parseFloat(priceField.getText()), Integer.parseInt(quantityField.getText()));
                nameField.setText("");
                priceField.setText("");
                quantityField.setText("");
                pieChart.setData(DBUtils.getInstance().getGroupedProducts());


            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });


        formRoot.setVgap(10);
        formRoot.addRow(0, headerLabel);
        formRoot.addRow(1, nameContainer);
        formRoot.addRow(2, priceContainer);
        formRoot.addRow(3, quantityContainer);
        formRoot.addRow(4, addButton);
        formRoot.setStyle("-fx-background-color: #fff; -fx-padding: 20; -fx-border-radius: 50; -fx-background-radius: 10;");
        formRoot.setMargin(addButton, new Insets(50, 0, 0, 0));

        GridPane chartRoot = new GridPane();
        chartRoot.addRow(0, pieChart);
        chartRoot.setStyle("-fx-background-color: #fff; -fx-padding: 20; -fx-border-radius: 50; -fx-background-radius: 10;");


        root.addRow(0, formRoot, chartRoot);

        Scene scene = new Scene(root, 1000, 500);
        stage.setTitle("Products");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}