package com.example.dato_kuknishvili_final;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//CREATE TABLE Products (
//        id INT PRIMARY KEY AUTO_INCREMENT,
//        name VARCHAR(255) NOT NULL,
//price DECIMAL(10, 2) NOT NULL,
//quantity INT NOT NULL
//);

public class DBUtils {
    private static String URL = "jdbc:mysql://localhost:3306/product";
    private static String USERNAME = "root";
    private static String PASSWORD = "";
    private Statement statement;
    private static DBUtils instance;


    public synchronized static DBUtils getInstance() {
        if (instance == null) {
            instance = new DBUtils();
        }
        return instance;

    }

    public void openConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        this.statement = connection.createStatement();

    }

    public void insertProduct(String name, float price, int quantity) throws SQLException {
        String sql = "insert into Products (name, price, quantity) values ('" + name + "'," + price + "," + quantity + ")";
        statement.execute(sql);
    }

    public ObservableList<PieChart.Data> getGroupedProducts() throws SQLException {
        String sql = "select * from Products";
        ResultSet res = statement.executeQuery(sql);

        List<Product> products = new ArrayList<>();


        while (res.next()) {
            products.add(new Product(res.getInt("id"), res.getString("name"), res.getInt("quantity"), res.getFloat("price") ));
        }

        Map<String, Long> groupedData = products.stream()
                .collect(Collectors.groupingBy(
                        product -> String.valueOf((product.getQuantity() / 10) * 10),
                        Collectors.counting()
                ));

        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        groupedData.forEach((quantityRange, count) -> {
            data.add(new PieChart.Data(quantityRange, count));
        });

        return data;
    }
//    public void updateRecord(int id, String name) throws SQLException {
//        String sql = "update Books set Title ='" + name + "' where ID=" + id;
//        statement.executeQuery(sql);
//    }
//
//    public void deleteRecord(int id) throws SQLException {
//        String sql = "delete  from Books where ID=" + id;
//        statement.executeQuery(sql);
//    }

}
