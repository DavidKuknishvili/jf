module com.example.dato_kuknishvili_final {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires static lombok;
    requires java.sql;

    opens com.example.dato_kuknishvili_final to javafx.fxml;
    exports com.example.dato_kuknishvili_final;
}